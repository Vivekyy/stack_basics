public class TwoStackTester{
    
    public static void main(String[] args){
        
        TwoStackQueue<Integer> a = new TwoStackQueue<Integer>();
        
        if(a.isEmpty())
            System.out.println("Good start");
               
        for (int i=1; i<=10; i++){
            a.enqueue(i);
            System.out.println("Added: "+i);
            System.out.println("Size = "+a.size());
            if(a.isEmpty())
                System.out.println(":(");
        }
        
        for (int i=1; i<=10; i++){
            if(a.isEmpty())
                System.out.println(":((");
            System.out.println("Removed: "+a.dequeue());
            System.out.println("Size = "+a.size());
        }
        
        if(a.isEmpty())
            System.out.println("Hooray!");
                
    }
    
}
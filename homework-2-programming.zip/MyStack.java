public class MyStack<T>{
    
    private int size;
    private T[] array;
    
    public MyStack(){
        size = 0;
        array = (T[]) new Object[20];
    }
    
    public void push(T x){
        ensureCapacity(++size);
        array[size-1] = x;
    }
    
	public T pop(){
        return array[--size];
    }
    
	public T peek(){
        return array[size-1];
    }
    
	public boolean isEmpty(){
        if (size==0)
            return true;
        return false;
    }
    
	public int size(){
        return size;
    }
    
    private void ensureCapacity(int n){
        if (n<=array.length)
            return;
        
        int oldLength = array.length;
        T[] temp = (T[]) new Object[oldLength*2+1];
        for(int i=0; i<oldLength; i++){
            temp[i] = array[i];
        }
        array = temp;
    }
    
}
import java.io.File;
import java.util.Scanner;

public class SymbolBalance{
    
    private MyStack<Character> stack;
    private Scanner scanner;
    
    public void setFile(String filename){
        stack = new MyStack<Character>();
        try{
            scanner = new Scanner(new File(filename));
        }
        catch(java.io.FileNotFoundException e){
            System.out.println("Invalid file input");
        }
    }
    
	public BalanceError checkFile(){
        
        int lineNumber = 0;
        
        while(scanner.hasNextLine()){
            
            lineNumber++;
            
            char[] current = scanner.nextLine().toCharArray();
            
            for(int i=0; i<current.length; i++){

                char x=current[i];
                
                if (x== '"' && !inComment()){ //Weird case as left " is the same as right "
                    if (stack.isEmpty())//So that you don't try to peek an empty stack
                        stack.push(x);
                    else if (stack.peek()==x)
                        stack.pop();//Don't need to compare since you already know it's equal
                    else
                        stack.push(x);
                    }
                
                if (x== '/' && !inString()){ //Weird case because /* and */ are two characters long
                    if(current.length>i+1)//Avoid going over limit of current array
                        if(current[i+1]=='*' && !inComment()){// This signifies /*
                            stack.push('*');
                        }
                    if(i>0){//Avoid going under limit of current array
                        if(current[i-1]=='*'){// This signifies */
                            if(stack.isEmpty()){
                                return new EmptyStackError(lineNumber);
                            }
                            else if (compare(x, stack.peek()) == -1){ //This shouldn't be possible
                                return new MismatchError(lineNumber, x, stack.pop()); 
                            }
                            else{
                                stack.pop();
                            }
                        }
                    }
                }

                if ((x=='{' || x=='(' || x=='[') && (!inString() && !inComment()))
                    stack.push(x);
                if ((x=='}' || x==')' || x==']') && (!inString() && !inComment())){
                    if(stack.isEmpty())
                        return new EmptyStackError(lineNumber);
                    else if (compare(x, stack.peek()) == -1)
                        return new MismatchError(lineNumber, x, stack.pop());
                    else
                        stack.pop();
                }
            }     
            
        }
        
        if(!stack.isEmpty())
            return new NonEmptyStackError(stack.peek(), stack.size()); //peek so stack size is unchanged
        
        return null;
    }
                     // returns either MismatchError(int lineNumber, char currentSymbol, char symbolPopped)
					 //                EmptyStackError(int lineNumber), 
					 //                NonEmptyStackError(char topElement, int sizeOfStack). 
					 // All three classes implement BalanceError

    private int compare(char x, char topStack){
        
        switch(topStack){
            case '(':
                if (x==')')
                    return 1;
                return -1;
            case '[':
                if (x==']')
                    return 1;
                return -1;
            case '{':
                if (x=='}')
                    return 1;
                return -1;
            //These next two shouldn't be able to happen
            case '"':
                System.out.println("Error with handling strings");
                if (x=='"')
                    return 1;
                return -1;
            case '*':
                if (x=='/')
                    return 1;
                System.out.println("Error with handling comments");
                return -1;  
        }
        
        System.out.println("Bad input to compare");
        return -1;
    }
    
    private boolean inString(){
        if(stack.isEmpty())
            return false;
        else if(stack.peek()=='"')
            return true;
        else
            return false;
    }
    
    private boolean inComment(){
        if(stack.isEmpty())
            return false;
        else if(stack.peek()=='*')
            return true;
        else
            return false;
    }
    
}
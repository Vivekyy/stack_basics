public class SymbolBalanceTester{
    
    public static void main(String[] args){
        
        SymbolBalance tester = new SymbolBalance();
        
        tester.setFile("TestFiles/Test1.java");
        System.out.println(tester.checkFile());
        
        tester.setFile("TestFiles/Test2.java");
        System.out.println(tester.checkFile());
        
        tester.setFile("TestFiles/Test3.java");
        System.out.println(tester.checkFile());
        
        tester.setFile("TestFiles/Test4.java");
        System.out.println(tester.checkFile());
        
        tester.setFile("TestFiles/Test5.java");
        System.out.println(tester.checkFile());
        
        tester.setFile("TestFiles/Test6.java");
        System.out.println(tester.checkFile());
        
        tester.setFile("TestFiles/Test7.java");
        System.out.println(tester.checkFile());
        
    }
    
}
public class TwoStackQueue<T>{
    
    private MyStack<T> inputStack;
    private MyStack<T> outputStack;
    
    public TwoStackQueue(){
        inputStack = new MyStack<T>();
        outputStack = new MyStack<T>();
    }
    
    public void enqueue(T x){
        inputStack.push(x);
    }
	public T dequeue(){
        int numMoves = inputStack.size();
        for (int i=0; i<numMoves; i++){
            outputStack.push(inputStack.pop());
        }
        T output = outputStack.pop(); //Don't return yet because need to push back to input stack
        for (int i=0; i<numMoves-1; i++){
            inputStack.push(outputStack.pop());
        }
        return output;
    }
	public int size(){
        return inputStack.size();
    }
	public boolean isEmpty(){
        return inputStack.isEmpty();
    }
    
}